SCORES_FILE_NAME = 'scores.txt'
BAD_RETURN_CODE = "403"


def screen_cleaner():
    print('\r', end='')

